package com.countdown;

import com.countdown.commands.CountDownCommand;
import com.countdown.listeners.PlayerListener;
import com.countdown.managers.CountDownManager;
import com.countdown.storage.PlayerStorage;
import org.bukkit.plugin.java.JavaPlugin;

public class CountDownPlugin extends JavaPlugin {

    private static CountDownPlugin instance;
    private PlayerStorage storage;
    private CountDownManager manager;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();
        getConfig().options().copyDefaults(true);
        saveConfig();

        this.storage = new PlayerStorage(this);
        this.manager = new CountDownManager(this);

        getCommand("deathcd").setExecutor(new CountDownCommand(this));
        getServer().getPluginManager().registerEvents(new PlayerListener(this), this);

        getLogger().info("CountDown plugin enabled!");
    }

    @Override
    public void onDisable() {
        storage.saveAll();
        getLogger().info("CountDown plugin disabled!");
    }

    public static CountDownPlugin getInstance() {
        return instance;
    }

    public PlayerStorage getStorage() {
        return storage;
    }

    public CountDownManager getManager() {
        return manager;
    }
}