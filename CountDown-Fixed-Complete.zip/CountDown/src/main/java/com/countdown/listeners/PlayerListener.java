package com.countdown.listeners;

import com.countdown.CountDownPlugin;
import com.countdown.managers.CountDownManager;
import com.countdown.models.CountDownPlayer;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public class PlayerListener implements Listener {

    private final CountDownPlugin plugin;
    private final CountDownManager manager;

    public PlayerListener(CountDownPlugin plugin) {
        this.plugin = plugin;
        this.manager = plugin.getManager();
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        manager.startTimer(p);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        manager.stopTimer(e.getPlayer().getUniqueId());
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent e) {
        Player victim = e.getEntity();
        Player killer = victim.getKiller();

        CountDownPlayer victimData = plugin.getStorage().getPlayerData(victim.getUniqueId());
        long victimTime = victimData.getRemainingSeconds();

        if (killer != null && killer != victim) {
            long reward = Math.min(21600, victimTime);
            manager.addTime(killer.getUniqueId(), reward);
            String timeStr = formatSeconds(reward);
            killer.sendMessage(ChatColor.translateAlternateColorCodes('&', "&fYou gained &b" + timeStr + "&f from &b" + victim.getName()));
        }

        if (victimTime > 0) {
            manager.removeTime(victim.getUniqueId(), 21600);
            victim.sendMessage(ChatColor.translateAlternateColorCodes('&', "&fYou lost &b6 hours&f."));
        }
    }

    private String formatSeconds(long seconds) {
        long h = seconds / 3600;
        return h + " hours";
    }
}