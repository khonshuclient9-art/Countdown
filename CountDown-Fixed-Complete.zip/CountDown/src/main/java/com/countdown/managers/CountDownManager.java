package com.countdown.managers;

import com.countdown.CountDownPlugin;
import com.countdown.models.CountDownPlayer;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scoreboard.Team;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class CountDownManager {

    private final CountDownPlugin plugin;
    private final Map<UUID, BukkitRunnable> timers = new HashMap<>();

    public CountDownManager(CountDownPlugin plugin) {
        this.plugin = plugin;
    }

    public void startTimer(Player player) {
        stopTimer(player.getUniqueId());
        BukkitRunnable task = new BukkitRunnable() {
            @Override
            public void run() {
                if (!player.isOnline()) {
                    cancel();
                    return;
                }
                CountDownPlayer cdp = plugin.getStorage().getPlayerData(player.getUniqueId());
                long remaining = cdp.getRemainingSeconds();

                String timeStr = formatTime(remaining);
                String color = remaining <= plugin.getConfig().getInt("critical-threshold", 10) ? 
                    ChatColor.RED.toString() : ChatColor.AQUA.toString();

                player.sendActionBar(Component.text(color + timeStr));

                updateNametag(player, color + timeStr);

                if (remaining <= 10 && remaining > 0) {
                    player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 1.0f, 1.0f);
                }

                if (remaining <= 0 && !cdp.isBypassed() && !cdp.isPaused()) {
                    handleExpiration(player);
                    cancel();
                }
            }
        };
        task.runTaskTimer(plugin, 0L, 20L);
        timers.put(player.getUniqueId(), task);
    }

    private void updateNametag(Player player, String timeStr) {
        org.bukkit.scoreboard.Scoreboard board = Bukkit.getScoreboardManager().getMainScoreboard();
        Team team = board.getTeam("countdown");
        if (team == null) {
            team = board.registerNewTeam("countdown");
        }
        team.setSuffix(" §7| " + timeStr);
        team.addEntry(player.getName());
    }

    public void stopTimer(UUID uuid) {
        BukkitRunnable task = timers.remove(uuid);
        if (task != null) task.cancel();
    }

    private String formatTime(long seconds) {
        long h = seconds / 3600;
        long m = (seconds % 3600) / 60;
        long s = seconds % 60;
        return String.format("%02d:%02d:%02d", h, m, s);
    }

    private void handleExpiration(Player player) {
        String msg = plugin.getConfig().getString("messages.player-out-of-time", "&b{player} &fhas run out of time...");
        Bukkit.broadcast(Component.text(ChatColor.translateAlternateColorCodes('&', msg.replace("{player}", player.getName()))));
        player.banPlayer(plugin.getConfig().getString("ban-reason", "You ran out of time."));
    }

    public void addTime(UUID uuid, long seconds) {
        CountDownPlayer cdp = plugin.getStorage().getPlayerData(uuid);
        cdp.setExpirationTime(cdp.getExpirationTime() + seconds * 1000);
        plugin.getStorage().savePlayer(cdp);
    }

    public void removeTime(UUID uuid, long seconds) {
        CountDownPlayer cdp = plugin.getStorage().getPlayerData(uuid);
        cdp.setExpirationTime(Math.max(System.currentTimeMillis(), cdp.getExpirationTime() - seconds * 1000));
        plugin.getStorage().savePlayer(cdp);
    }

    public void setTime(UUID uuid, long seconds) {
        CountDownPlayer cdp = plugin.getStorage().getPlayerData(uuid);
        cdp.setExpirationTime(System.currentTimeMillis() + seconds * 1000);
        plugin.getStorage().savePlayer(cdp);
    }

    public long getRemainingTime(UUID uuid) {
        CountDownPlayer cdp = plugin.getStorage().getPlayerData(uuid);
        return cdp.getRemainingSeconds();
    }

    public boolean toggleBypass(UUID uuid) {
        CountDownPlayer cdp = plugin.getStorage().getPlayerData(uuid);
        boolean newState = !cdp.isBypassed();
        cdp.setBypassed(newState);
        plugin.getStorage().savePlayer(cdp);
        return newState;
    }

    public void setPaused(UUID uuid, boolean paused) {
        CountDownPlayer cdp = plugin.getStorage().getPlayerData(uuid);
        cdp.setPaused(paused);
        plugin.getStorage().savePlayer(cdp);
    }
}