package com.countdown.models;

import java.util.UUID;

public class CountDownPlayer {
    private final UUID uuid;
    private long expirationTime;
    private boolean paused;
    private boolean bypassed;

    public CountDownPlayer(UUID uuid, long expirationTime) {
        this.uuid = uuid;
        this.expirationTime = expirationTime;
        this.paused = false;
        this.bypassed = false;
    }

    public UUID getUuid() { return uuid; }
    public long getExpirationTime() { return expirationTime; }
    public void setExpirationTime(long expirationTime) { this.expirationTime = expirationTime; }
    public boolean isPaused() { return paused; }
    public void setPaused(boolean paused) { this.paused = paused; }
    public boolean isBypassed() { return bypassed; }
    public void setBypassed(boolean bypassed) { this.bypassed = bypassed; }

    public long getRemainingSeconds() {
        if (bypassed) return 0;
        if (paused) return (expirationTime - System.currentTimeMillis()) / 1000;
        return Math.max(0, (expirationTime - System.currentTimeMillis()) / 1000);
    }
}