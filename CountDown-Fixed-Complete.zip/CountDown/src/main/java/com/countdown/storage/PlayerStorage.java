package com.countdown.storage;

import com.countdown.CountDownPlugin;
import com.countdown.models.CountDownPlayer;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import org.bukkit.Bukkit;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class PlayerStorage {
    private final CountDownPlugin plugin;
    private final File dataFile;
    private final Gson gson = new Gson();
    private final Map<UUID, CountDownPlayer> players = new HashMap<>();

    public PlayerStorage(CountDownPlugin plugin) {
        this.plugin = plugin;
        this.dataFile = new File(plugin.getDataFolder(), "players.json");
        load();
    }

    public void load() {
        if (dataFile.exists()) {
            try (FileReader reader = new FileReader(dataFile)) {
                Type type = new TypeToken<Map<UUID, CountDownPlayer>>() {}.getType();
                Map<UUID, CountDownPlayer> loaded = gson.fromJson(reader, type);
                if (loaded != null) players.putAll(loaded);
            } catch (IOException e) {
                plugin.getLogger().warning("Failed to load player data");
            }
        }
    }

    public void saveAll() {
        try (FileWriter writer = new FileWriter(dataFile)) {
            gson.toJson(players, writer);
        } catch (IOException e) {
            plugin.getLogger().warning("Failed to save player data");
        }
    }

    public CountDownPlayer getPlayerData(UUID uuid) {
        return players.computeIfAbsent(uuid, k -> {
            long start = parseTime(plugin.getConfig().getString("starting-time", "24h"));
            return new CountDownPlayer(uuid, System.currentTimeMillis() + start * 1000);
        });
    }

    public void savePlayer(CountDownPlayer player) {
        players.put(player.getUuid(), player);
        saveAll();
    }

    private long parseTime(String timeStr) {
        timeStr = timeStr.toLowerCase().trim();
        long multiplier = 1;
        if (timeStr.endsWith("d")) multiplier = 86400;
        else if (timeStr.endsWith("h")) multiplier = 3600;
        else if (timeStr.endsWith("m")) multiplier = 60;
        else if (timeStr.endsWith("s")) multiplier = 1;
        String num = timeStr.replaceAll("[^0-9]", "");
        return Long.parseLong(num) * multiplier;
    }
}