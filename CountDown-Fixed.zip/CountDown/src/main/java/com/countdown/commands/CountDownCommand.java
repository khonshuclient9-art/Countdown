package com.countdown.commands;

import com.countdown.CountDownPlugin;
import com.countdown.managers.CountDownManager;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.UUID;

public class CountDownCommand implements CommandExecutor {

    private final CountDownPlugin plugin;
    private final CountDownManager manager;

    public CountDownCommand(CountDownPlugin plugin) {
        this.plugin = plugin;
        this.manager = plugin.getManager();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("deathcd.admin")) {
            sender.sendMessage(ChatColor.RED + "No permission!");
            return true;
        }

        if (args.length == 0) {
            sendHelp(sender);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "list":
                sendHelp(sender);
                break;
            case "add":
                handleAdd(sender, args);
                break;
            case "remove":
                handleRemove(sender, args);
                break;
            case "set":
                handleSet(sender, args);
                break;
            case "time":
                handleTime(sender, args);
                break;
            case "bypass":
                handleBypass(sender, args);
                break;
            case "pause":
                handlePause(sender, args, true);
                break;
            case "unpause":
                handlePause(sender, args, false);
                break;
            case "reload":
                plugin.reloadConfig();
                sender.sendMessage(ChatColor.GREEN + "Config reloaded!");
                break;
            default:
                sendHelp(sender);
        }
        return true;
    }

    private void sendHelp(CommandSender sender) {
        sender.sendMessage(ChatColor.AQUA + "=== CountDown Commands ===");
        sender.sendMessage(ChatColor.WHITE + "/deathcd list - Show this help");
        sender.sendMessage(ChatColor.WHITE + "/deathcd add <player> <time>");
        sender.sendMessage(ChatColor.WHITE + "/deathcd remove <player> <time>");
        sender.sendMessage(ChatColor.WHITE + "/deathcd set <player> <time>");
        sender.sendMessage(ChatColor.WHITE + "/deathcd time <player>");
        sender.sendMessage(ChatColor.WHITE + "/deathcd bypass <player>");
        sender.sendMessage(ChatColor.WHITE + "/deathcd pause <player>");
        sender.sendMessage(ChatColor.WHITE + "/deathcd unpause <player>");
        sender.sendMessage(ChatColor.WHITE + "/deathcd reload");
    }

    private void handleAdd(CommandSender sender, String[] args) {
        if (args.length < 3) return;
        Player target = Bukkit.getPlayer(args[1]);
        if (target == null) {
            sender.sendMessage(ChatColor.RED + "Player not found");
            return;
        }
        long seconds = parseTime(args[2]);
        manager.addTime(target.getUniqueId(), seconds);
        sender.sendMessage(ChatColor.GREEN + "Added time to " + target.getName());
    }

    // Similar for remove, set, time, bypass, pause...
    private long parseTime(String str) {
        // Simple parser
        str = str.toLowerCase();
        long val = Long.parseLong(str.replaceAll("[^0-9]", ""));
        if (str.endsWith("d")) val *= 86400;
        else if (str.endsWith("h")) val *= 3600;
        else if (str.endsWith("m")) val *= 60;
        return val;
    }

    // Stub other handlers for now (full implementation would expand them)
    private void handleRemove(CommandSender sender, String[] args) { /* implement */ }
    private void handleSet(CommandSender sender, String[] args) { /* implement */ }
    private void handleTime(CommandSender sender, String[] args) { /* implement */ }
    private void handleBypass(CommandSender sender, String[] args) { /* implement */ }
    private void handlePause(CommandSender sender, String[] args, boolean pause) { /* implement */ }
}