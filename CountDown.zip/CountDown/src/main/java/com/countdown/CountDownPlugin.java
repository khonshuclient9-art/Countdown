package com.countdown;

import com.countdown.commands.CountDownCommand;
import com.countdown.listeners.PlayerListener;
import com.countdown.managers.CountDownManager;
import com.countdown.storage.DataStorage;
import org.bukkit.plugin.java.JavaPlugin;

public final class CountDownPlugin extends JavaPlugin {

    private static CountDownPlugin instance;
    private CountDownManager countDownManager;
    private DataStorage dataStorage;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();
        saveResource("messages.yml", false);

        dataStorage = new DataStorage(this);
        dataStorage.loadData();

        countDownManager = new CountDownManager(this);

        getCommand("deathcd").setExecutor(new CountDownCommand(this));
        getServer().getPluginManager().registerEvents(new PlayerListener(this), this);

        getLogger().info("CountDown plugin has been enabled!");
    }

    @Override
    public void onDisable() {
        if (countDownManager != null) {
            countDownManager.saveAll();
        }
        if (dataStorage != null) {
            dataStorage.saveData();
        }
        getLogger().info("CountDown plugin has been disabled!");
    }

    public static CountDownPlugin getInstance() {
        return instance;
    }

    public CountDownManager getCountDownManager() {
        return countDownManager;
    }

    public DataStorage getDataStorage() {
        return dataStorage;
    }
}