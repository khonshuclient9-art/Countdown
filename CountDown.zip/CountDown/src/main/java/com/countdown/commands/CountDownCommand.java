package com.countdown.commands;

import com.countdown.CountDownPlugin;
import com.countdown.managers.CountDownManager;
import com.countdown.models.PlayerData;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.UUID;

public class CountDownCommand implements CommandExecutor {

    private final CountDownPlugin plugin;
    private final CountDownManager manager;

    public CountDownCommand(CountDownPlugin plugin) {
        this.plugin = plugin;
        this.manager = plugin.getCountDownManager();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("deathcd.admin")) {
            sender.sendMessage(ChatColor.RED + "You don't have permission to use this command.");
            return true;
        }

        if (args.length == 0) {
            sendHelp(sender);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "list":
                sendHelp(sender);
                break;
            case "add":
                handleAdd(sender, args);
                break;
            case "remove":
                handleRemove(sender, args);
                break;
            case "set":
                handleSet(sender, args);
                break;
            case "time":
                handleTime(sender, args);
                break;
            case "bypass":
                handleBypass(sender, args);
                break;
            case "pause":
                handlePause(sender, args);
                break;
            case "unpause":
                handleUnpause(sender, args);
                break;
            case "reload":
                plugin.reloadConfig();
                sender.sendMessage(ChatColor.GREEN + "Config reloaded!");
                break;
            default:
                sendHelp(sender);
        }
        return true;
    }

    private void sendHelp(CommandSender sender) {
        sender.sendMessage(ChatColor.GOLD + "=== CountDown Commands ===");
        sender.sendMessage(ChatColor.YELLOW + "/deathcd list " + ChatColor.WHITE + "- Show this help");
        sender.sendMessage(ChatColor.YELLOW + "/deathcd add <player> <time> " + ChatColor.WHITE + "- Add time (e.g. 6h)");
        sender.sendMessage(ChatColor.YELLOW + "/deathcd remove <player> <time> " + ChatColor.WHITE + "- Remove time");
        sender.sendMessage(ChatColor.YELLOW + "/deathcd set <player> <time> " + ChatColor.WHITE + "- Set time");
        sender.sendMessage(ChatColor.YELLOW + "/deathcd time <player> " + ChatColor.WHITE + "- Check time");
        sender.sendMessage(ChatColor.YELLOW + "/deathcd bypass <player> " + ChatColor.WHITE + "- Toggle bypass");
        sender.sendMessage(ChatColor.YELLOW + "/deathcd pause <player> " + ChatColor.WHITE + "- Pause timer");
        sender.sendMessage(ChatColor.YELLOW + "/deathcd unpause <player> " + ChatColor.WHITE + "- Unpause timer");
        sender.sendMessage(ChatColor.YELLOW + "/deathcd reload " + ChatColor.WHITE + "- Reload config");
    }

    private void handleAdd(CommandSender sender, String[] args) {
        if (args.length < 3) {
            sender.sendMessage(ChatColor.RED + "Usage: /deathcd add <player> <time>");
            return;
        }
        Player target = Bukkit.getPlayer(args[1]);
        if (target == null) {
            sender.sendMessage(ChatColor.RED + "Player not found!");
            return;
        }
        long time = parseTime(args[2]);
        if (time <= 0) {
            sender.sendMessage(ChatColor.RED + "Invalid time format!");
            return;
        }
        manager.addTime(target.getUniqueId(), time);
        sender.sendMessage(ChatColor.GREEN + "Added time to " + target.getName());
    }

    private long parseTime(String input) {
        try {
            long value = Long.parseLong(input.replaceAll("[^0-9]", ""));
            if (input.endsWith("d")) return value * 86400000L;
            if (input.endsWith("h")) return value * 3600000L;
            if (input.endsWith("m")) return value * 60000L;
            if (input.endsWith("s")) return value * 1000L;
            return value * 1000L; // default seconds
        } catch (Exception e) {
            return 0;
        }
    }

    private void handleRemove(CommandSender sender, String[] args) {
        if (args.length < 3) {
            sender.sendMessage(ChatColor.RED + "Usage: /deathcd remove <player> <time>");
            return;
        }
        Player target = Bukkit.getPlayer(args[1]);
        if (target == null) {
            sender.sendMessage(ChatColor.RED + "Player not found!");
            return;
        }
        long time = parseTime(args[2]);
        if (time <= 0) {
            sender.sendMessage(ChatColor.RED + "Invalid time format!");
            return;
        }
        manager.removeTime(target.getUniqueId(), time);
        sender.sendMessage(ChatColor.GREEN + "Removed time from " + target.getName());
    }

    private void handleSet(CommandSender sender, String[] args) {
        if (args.length < 3) {
            sender.sendMessage(ChatColor.RED + "Usage: /deathcd set <player> <time>");
            return;
        }
        Player target = Bukkit.getPlayer(args[1]);
        if (target == null) {
            sender.sendMessage(ChatColor.RED + "Player not found!");
            return;
        }
        long time = parseTime(args[2]);
        if (time <= 0) {
            sender.sendMessage(ChatColor.RED + "Invalid time format!");
            return;
        }
        manager.setTime(target.getUniqueId(), time);
        sender.sendMessage(ChatColor.GREEN + "Set time for " + target.getName());
    }

    private void handleTime(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage(ChatColor.RED + "Usage: /deathcd time <player>");
            return;
        }
        Player target = Bukkit.getPlayer(args[1]);
        if (target == null) {
            sender.sendMessage(ChatColor.RED + "Player not found!");
            return;
        }
        PlayerData data = plugin.getDataStorage().getPlayerData(target.getUniqueId());
        sender.sendMessage(ChatColor.BLUE + target.getName() + "'s remaining time: " + manager.formatTime(data.getRemainingTime()));
    }

    private void handleBypass(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage(ChatColor.RED + "Usage: /deathcd bypass <player>");
            return;
        }
        Player target = Bukkit.getPlayer(args[1]);
        if (target == null) {
            sender.sendMessage(ChatColor.RED + "Player not found!");
            return;
        }
        PlayerData data = plugin.getDataStorage().getPlayerData(target.getUniqueId());
        boolean newBypass = !data.isBypassed();
        data.setBypassed(newBypass);
        plugin.getDataStorage().savePlayerData(data);
        sender.sendMessage(ChatColor.GREEN + "Bypass for " + target.getName() + ": " + newBypass);
    }

    private void handlePause(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage(ChatColor.RED + "Usage: /deathcd pause <player>");
            return;
        }
        Player target = Bukkit.getPlayer(args[1]);
        if (target == null) {
            sender.sendMessage(ChatColor.RED + "Player not found!");
            return;
        }
        PlayerData data = plugin.getDataStorage().getPlayerData(target.getUniqueId());
        data.setPaused(true);
        plugin.getDataStorage().savePlayerData(data);
        sender.sendMessage(ChatColor.GREEN + "Paused timer for " + target.getName());
    }

    private void handleUnpause(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage(ChatColor.RED + "Usage: /deathcd unpause <player>");
            return;
        }
        Player target = Bukkit.getPlayer(args[1]);
        if (target == null) {
            sender.sendMessage(ChatColor.RED + "Player not found!");
            return;
        }
        PlayerData data = plugin.getDataStorage().getPlayerData(target.getUniqueId());
        data.setPaused(false);
        plugin.getDataStorage().savePlayerData(data);
        sender.sendMessage(ChatColor.GREEN + "Unpaused timer for " + target.getName());
    }
}