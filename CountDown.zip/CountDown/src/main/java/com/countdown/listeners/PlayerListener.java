package com.countdown.listeners;

import com.countdown.CountDownPlugin;
import com.countdown.managers.CountDownManager;
import com.countdown.models.PlayerData;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerJoinEvent;

public class PlayerListener implements Listener {

    private final CountDownPlugin plugin;
    private final CountDownManager manager;

    public PlayerListener(CountDownPlugin plugin) {
        this.plugin = plugin;
        this.manager = plugin.getCountDownManager();
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        // Timer starts on first join via DataStorage
        manager.updatePlayerDisplay(player);
    }

    @EventHandler
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player victim = event.getEntity();
        Player killer = victim.getKiller();

        PlayerData victimData = plugin.getDataStorage().getPlayerData(victim.getUniqueId());

        long penalty = plugin.getConfig().getLong("death-penalty", 21600000L); // 6 hours
        long victimRemaining = victimData.getRemainingTime();

        if (victimRemaining < penalty) {
            penalty = victimRemaining;
        }

        manager.removeTime(victim.getUniqueId(), penalty);
        victim.sendMessage(ChatColor.translateAlternateColorCodes('&', "&fYou lost &b" + manager.formatTime(penalty) + "&f."));

        if (killer != null && killer != victim) {
            manager.addTime(killer.getUniqueId(), penalty);
            String msg = "&fYou gained &b" + manager.formatTime(penalty) + "&f from &b" + victim.getName() + "&f.";
            killer.sendMessage(ChatColor.translateAlternateColorCodes('&', msg));
        }

        // Check if victim should be banned
        if (victimData.getRemainingTime() <= 0) {
            String broadcast = plugin.getConfig().getString("messages.expiration-broadcast", "&b{player} &fhas run out of time and has been banned from the server.")
                    .replace("{player}", victim.getName());
            Bukkit.broadcastMessage(ChatColor.translateAlternateColorCodes('&', broadcast));
            victim.banPlayer(plugin.getConfig().getString("ban-reason", "You ran out of time."));
        }
    }
}