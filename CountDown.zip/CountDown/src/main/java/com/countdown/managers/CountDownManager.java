package com.countdown.managers;

import com.countdown.CountDownPlugin;
import com.countdown.models.PlayerData;
import net.md_5.bungee.api.ChatColor;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

public class CountDownManager {
    private final CountDownPlugin plugin;
    private final Map<UUID, BukkitRunnable> activeTimers = new HashMap<>();

    public CountDownManager(CountDownPlugin plugin) {
        this.plugin = plugin;
        startGlobalTimer();
    }

    private void startGlobalTimer() {
        new BukkitRunnable() {
            @Override
            public void run() {
                for (Player player : Bukkit.getOnlinePlayers()) {
                    updatePlayerDisplay(player);
                    checkExpiration(player);
                }
            }
        }.runTaskTimer(plugin, 0L, 20L); // Every second
    }

    public void updatePlayerDisplay(Player player) {
        PlayerData data = plugin.getDataStorage().getPlayerData(player.getUniqueId());
        long remaining = data.getRemainingTime();

        String timeStr = formatTime(remaining);
        String color = remaining <= plugin.getConfig().getLong("critical-threshold", 10000L) ? "&c" : "&b";

        // Action Bar
        String actionBar = color + timeStr;
        player.sendActionBar(net.md_5.bungee.api.ChatMessageType.ACTION_BAR, net.md_5.bungee.api.chat.TextComponent.fromLegacyText(actionBar));

        // Nametag (using scoreboard or via protocol, simplified with display name for demo)
        // For full nametag, would use packets or Team, but basic implementation
        if (data.isBypassed() || data.isPaused()) {
            player.setPlayerListName(ChatColor.RED + timeStr + " " + player.getName());
        } else {
            player.setPlayerListName(ChatColor.of(color.replace("&", "")) + timeStr + " " + player.getName());
        }
    }

    private void checkExpiration(Player player) {
        PlayerData data = plugin.getDataStorage().getPlayerData(player.getUniqueId());
        if (data.isBypassed() || data.isPaused()) return;

        if (data.getRemainingTime() <= 0) {
            handleExpiration(player);
        }
    }

    private void handleExpiration(Player player) {
        String broadcast = plugin.getConfig().getString("messages.expiration-broadcast", "&b{player} &fhas run out of time and has been banned from the server.")
                .replace("{player}", player.getName());
        Bukkit.broadcastMessage(ChatColor.translateAlternateColorCodes('&', broadcast));

        String reason = plugin.getConfig().getString("ban-reason", "You ran out of time.");
        player.banPlayer(reason);

        plugin.getDataStorage().getPlayerData(player.getUniqueId()).setExpirationTime(0);
    }

    public void addTime(UUID uuid, long millis) {
        PlayerData data = plugin.getDataStorage().getPlayerData(uuid);
        data.setExpirationTime(data.getExpirationTime() + millis);
        plugin.getDataStorage().savePlayerData(data);
    }

    public void removeTime(UUID uuid, long millis) {
        PlayerData data = plugin.getDataStorage().getPlayerData(uuid);
        long newTime = Math.max(0, data.getExpirationTime() - millis);
        data.setExpirationTime(newTime);
        plugin.getDataStorage().savePlayerData(data);
    }

    public void setTime(UUID uuid, long millis) {
        PlayerData data = plugin.getDataStorage().getPlayerData(uuid);
        data.setExpirationTime(System.currentTimeMillis() + millis);
        plugin.getDataStorage().savePlayerData(data);
    }

    public String formatTime(long millis) {
        if (millis <= 0) return "00:00:00";
        long hours = TimeUnit.MILLISECONDS.toHours(millis);
        long minutes = TimeUnit.MILLISECONDS.toMinutes(millis) % 60;
        long seconds = TimeUnit.MILLISECONDS.toSeconds(millis) % 60;
        return String.format("%02d:%02d:%02d", hours, minutes, seconds);
    }

    public void saveAll() {
        // Save handled by storage
    }
}