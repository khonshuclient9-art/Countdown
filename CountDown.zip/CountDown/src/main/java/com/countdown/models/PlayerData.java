package com.countdown.models;

import java.util.UUID;

public class PlayerData {
    private final UUID uuid;
    private long expirationTime;
    private boolean paused;
    private boolean bypassed;

    public PlayerData(UUID uuid, long expirationTime) {
        this.uuid = uuid;
        this.expirationTime = expirationTime;
        this.paused = false;
        this.bypassed = false;
    }

    public UUID getUuid() {
        return uuid;
    }

    public long getExpirationTime() {
        return expirationTime;
    }

    public void setExpirationTime(long expirationTime) {
        this.expirationTime = expirationTime;
    }

    public boolean isPaused() {
        return paused;
    }

    public void setPaused(boolean paused) {
        this.paused = paused;
    }

    public boolean isBypassed() {
        return bypassed;
    }

    public void setBypassed(boolean bypassed) {
        this.bypassed = bypassed;
    }

    public long getRemainingTime() {
        if (bypassed || paused) {
            return 0;
        }
        long now = System.currentTimeMillis();
        return Math.max(0, expirationTime - now);
    }
}