package com.countdown.storage;

import com.countdown.CountDownPlugin;
import com.countdown.models.PlayerData;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import org.bukkit.Bukkit;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class DataStorage {
    private final CountDownPlugin plugin;
    private final File dataFile;
    private final Gson gson;
    private final Map<UUID, PlayerData> playerDataMap = new HashMap<>();

    public DataStorage(CountDownPlugin plugin) {
        this.plugin = plugin;
        this.dataFile = new File(plugin.getDataFolder(), "data.json");
        this.gson = new GsonBuilder().setPrettyPrinting().create();
        if (!dataFile.getParentFile().exists()) {
            dataFile.getParentFile().mkdirs();
        }
    }

    public void loadData() {
        if (dataFile.exists()) {
            try (FileReader reader = new FileReader(dataFile)) {
                Type type = new TypeToken<Map<UUID, PlayerData>>(){}.getType();
                Map<UUID, PlayerData> loaded = gson.fromJson(reader, type);
                if (loaded != null) {
                    playerDataMap.putAll(loaded);
                }
            } catch (IOException e) {
                plugin.getLogger().severe("Failed to load data: " + e.getMessage());
            }
        }
    }

    public void saveData() {
        try (FileWriter writer = new FileWriter(dataFile)) {
            gson.toJson(playerDataMap, writer);
        } catch (IOException e) {
            plugin.getLogger().severe("Failed to save data: " + e.getMessage());
        }
    }

    public PlayerData getPlayerData(UUID uuid) {
        return playerDataMap.computeIfAbsent(uuid, k -> {
            long startingTime = plugin.getConfig().getLong("starting-time", 86400000L); // 24 hours
            return new PlayerData(uuid, System.currentTimeMillis() + startingTime);
        });
    }

    public void savePlayerData(PlayerData data) {
        playerDataMap.put(data.getUuid(), data);
        saveData();
    }

    public Map<UUID, PlayerData> getAllData() {
        return playerDataMap;
    }
}